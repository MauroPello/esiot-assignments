#ifndef BLINK_WHILE_ENTERING_TASK_HPP
#define BLINK_WHILE_ENTERING_TASK_HPP
#include <Context.hpp>

#define BLINK_WHILE_ENTERING_INTERVAL 100

void blinkWhileEntering();

#endif