#ifndef BLINK_WHILE_WASHING_TASK_HPP
#define BLINK_WHILE_WASHING_TASK_HPP
#include <Context.hpp>

#define BLINK_WHILE_WASHING_INTERVAL 500

void blinkWhileWashing();

#endif