#ifndef CAR_WASHING_SYSTEM_TASK_HPP
#define CAR_WASHING_SYSTEM_TASK_HPP
#include <Context.hpp>

#define CAR_WASHING_INTERVAL 100

void carWashingSystem();

#endif