#ifndef MONITOR_TEMPERATURE_TASK_HPP
#define MONITOR_TEMPERATURE_TASK_HPP
#include <Context.hpp>

#define MONITOR_TEMPERATURE_INTERVAL 100

void monitorTemperature();

#endif