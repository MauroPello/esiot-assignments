NOTA:
Il programma si sviluppa in moduli consentendo una maggiore flessibilità.
Le specifiche implementative di Arduino sono incapsulate nel modulo "Utils",
per un aggiornamento circoscritto in caso cambi la piattaforma alla base.
L'entrypoint è "main.cpp" e come ambiente di sviluppo è stato scelto PlatformIO.

VIDEO FUNZIONAMENTO:
https://www.youtube.com/watch?v=_Kfn-7PGTGE

LINK TINKERCAD:
https://www.tinkercad.com/things/0leb6pfXCLd-grand-blorr/editel?sharecode=go1uc3ZAtTse1N0c3PiObH2CH4gTGUdZKAYlNRbcCcs